// import React from "react";
// import GoogleMapReact from "google-map-react";
// const GoogleMapMarkerTest = () => {
//   let  latitude= 33.6234944;
//   var  longitude= 73.06811309999999;
//     const renderMarkers = (map, maps) => {
//         let marker = new maps.Marker({
//         position: { lat: 21.2, lng: 32.4 },
//         map,
//         title: 'Hello World!'
//         });
//         return marker;
//        };
//   return (
//     //   AIzaSyCccVle225nxVsChsR9cGh-Tz1wLvKgeT8
//     <div style={{width:"100%",height:"100vh"}}>
//       <GoogleMapReact
//         bootstrapURLKeys={{ key: "AIzaSyCccVle225nxVsChsR9cGh-Tz1wLvKgeT8" }}
//         defaultCenter={{ lat: latitude, lng: longitude }}
//         defaultZoom={16}
//         yesIWantToUseGoogleMapApiInternals
//         onGoogleApiLoaded={({ map, maps }) => renderMarkers(map, maps)}
//       />
//     </div>
//   );
// };

// export default GoogleMapMarkerTest;
