import React from 'react'
import GoogleMapMarkerTest from './GoogleMapMarkerTest'
const Markers = () => {
    return (
        <div>
            <GoogleMapMarkerTest longitude={124} latitude={122}/>
        </div>
    )
}

export default Markers
